/**
 * dart.js v5
 * - Wind: alle 3-4s ändert sich, klarer Windsack + Kompass + Kraftanzeige
 * - Atmung: Fadenkreuz atmet, aber Spieler kann mit Maus/Finger ÜBERSTEUERN
 * - Das Fadenkreuz folgt exakt Maus/Finger + Atemoffset obendrauf
 */
const DartGame = {
  current: null,
  _lastConfig: null,
  _windTick: null,
  _breathTick: null,
  _animFrame: null,

  SECTORS: [20,1,18,4,13,6,10,15,2,17,3,19,7,16,8,11,14,9,12,5],

  start(config) {
    DartGame._lastConfig = config;
    const c = {
      player: { score:301, roundDarts:[] },
      cpu:    { score:301, roundDarts:[] },
      turn: 'player', dartsThisRound: 0,
      wind: this._newWind(),
      gameOver: false, winner: null,
      startTime: Date.now(), errors: 0,
      onComplete: config.onComplete,
      // Breathing: gentle oval offset on top of mouse aim
      breath: { phase: 0, ox: 0, oy: 0 },
      // Aim: actual mouse/touch position on canvas (canvas coords)
      aimCx: 135, aimCy: 135, _BS: 270, // updated on first render (will become BS/2)
      // Whether player has moved the mouse yet
      playerAiming: false,
    };
    DartGame.current = c;
    this._render();

    // Wind changes every 3-4 seconds (slower, more readable)
    const windDelay = () => 3000 + Math.random() * 1000;
    const scheduleWind = () => {
      this._windTick = setTimeout(() => {
        if (this.current && !this.current.gameOver) {
          this.current.wind = this._newWind();
          this._refreshWindDisplay();
          scheduleWind();
        }
      }, windDelay());
    };
    scheduleWind();

    // Breathing animation (30fps) — only offset, mouse overrides
    this._breathTick = setInterval(() => {
      if (!this.current || this.current.gameOver) return;
      const b = this.current.breath;
      b.phase += 0.018; // slow breathing
      b.ox = Math.cos(b.phase * 0.7) * 12;
      b.oy = Math.sin(b.phase) * 18;
      this._updateCrosshair();
    }, 33);
  },

  _show180() {
    // 🎉 ONE HUNDRED AND EIGHTY! 🎉
    // Play sound using Web Audio
    try {
      const ctx = new (window.AudioContext||window.webkitAudioContext)();
      // Fanfare: ascending triumphant notes
      // Dramatic fanfare - crowd roar then melody
      const notes = [
        // Drum roll effect
        [120,0,0.05],[120,0.06,0.05],[120,0.11,0.05],[120,0.15,0.05],
        // Triumphant melody
        [523,0.22,0.12],[659,0.36,0.12],[784,0.50,0.12],
        [1047,0.65,0.35],[784,0.65,0.35]
      ];
      notes.forEach(([freq,start,dur])=>{
        const o=ctx.createOscillator();const g=ctx.createGain();
        o.type='square';o.frequency.setValueAtTime(freq,ctx.currentTime+start);
        g.gain.setValueAtTime(0,ctx.currentTime+start);
        g.gain.linearRampToValueAtTime(0.15,ctx.currentTime+start+0.02);
        g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+start+dur);
        o.connect(g);g.connect(ctx.destination);
        o.start(ctx.currentTime+start);o.stop(ctx.currentTime+start+dur+0.05);
      });
    } catch(e){}

    // Speech synthesis "ONE HUNDRED AND EIGHTY!"
    try {
      // Passionate dart caller voice
      const sayIt = () => {
        const u = new SpeechSynthesisUtterance('ONE HUNDRED AND EIGHTY!');
        u.rate = 0.85;   // Slower = more dramatic
        u.pitch = 0.6;   // Deep voice
        u.volume = 1;
        // Prefer UK English for authentic dart feel
        const voices = speechSynthesis.getVoices();
        const uk = voices.find(v=>v.lang==='en-GB'&&v.name.toLowerCase().includes('male'))
          || voices.find(v=>v.lang==='en-GB')
          || voices.find(v=>v.lang.startsWith('en'));
        if(uk) u.voice = uk;
        speechSynthesis.speak(u);
      };
      // Wait for voices to load if needed
      if(speechSynthesis.getVoices().length) sayIt();
      else speechSynthesis.onvoiceschanged = sayIt;
    } catch(e){}

    // Visual animation overlay
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;pointer-events:none;background:rgba(0,0,0,.3)';
    overlay.innerHTML = `
      <div style="text-align:center;animation:pop180 0.4s ease">
        <div style="font-size:5rem;animation:spin180 1s linear infinite">🎯</div>
        <div style="font-family:'Fredoka One',cursive;font-size:3rem;color:#FFD700;text-shadow:0 0 30px #FFD700,0 0 60px #FF6600;letter-spacing:2px">180!</div>
        <div style="font-size:1.1rem;color:#fff;font-weight:900;letter-spacing:4px;margin-top:6px">ONE HUNDRED AND EIGHTY!</div>
      </div>`;
    // Add keyframe animations
    if(!document.getElementById('dart180css')){
      const st=document.createElement('style');st.id='dart180css';
      st.textContent='@keyframes pop180{0%{transform:scale(0) rotate(-10deg)}60%{transform:scale(1.15) rotate(3deg)}100%{transform:scale(1)}}@keyframes spin180{to{transform:rotate(360deg)}}';
      document.head.appendChild(st);
    }
    document.body.appendChild(overlay);
    setTimeout(()=>overlay.remove(), 2800);
  },

  _newWind() {
    const angle = Math.random() * 360;
    const strength = Math.random() * 3.5;
    const _deWind = {'dart.wind.calm':'Windstill','dart.wind.light':'Leichte Brise','dart.wind.moderate':'Mäßig','dart.wind.strong':'Stark','dart.wind.storm':'Sturm'};
    const _tt = (k)=> typeof t!=='undefined'?t(k):_deWind[k];
    const names = [_tt('dart.wind.calm'),_tt('dart.wind.light'),_tt('dart.wind.moderate'),_tt('dart.wind.strong'),_tt('dart.wind.storm')];
    const ni = Math.min(4, Math.floor(strength / 0.7));
    return { angle, strength, name: names[ni] };
  },

  _render() {
    const c = this.current;
    const isP = c.turn === 'player';
    const el2 = document.getElementById('game-area');
    const avW = Math.min(el2 ? (el2.offsetWidth||window.innerWidth) : window.innerWidth, window.innerWidth) - 16;
    const isMob2 = 'ontouchstart' in window;
    const isPortrait = window.innerHeight > window.innerWidth;
    // Board size: big on portrait mobile, standard elsewhere
    // Portrait: board fills screen width; Landscape: board fills screen height
    const BS = isMob2
      ? (isPortrait
          ? Math.min(avW - 4, Math.round(window.innerHeight * 0.44))  // portrait: near full width
          : Math.min(Math.round(window.innerHeight - 80), Math.round(avW * 0.55)))  // landscape: height-based
      : 320; // desktop
    const CX = Math.round(BS/2), CY = Math.round(BS/2);
    if(this.current) {
      this.current._BS = BS;
      // Always update aim center to match actual board center
      this.current.aimCx = CX;
      this.current.aimCy = CY;
    }
    document.getElementById('game-area').innerHTML = `
<div style="padding:0 2px;width:100%;box-sizing:border-box;overflow:hidden">

${(isMob2&&!isPortrait)?`
<div style="display:flex;gap:8px;align-items:flex-start;width:100%">
  <div style="display:flex;flex-direction:column;gap:4px;width:88px;flex-shrink:0">
    <div style="background:${isP?'linear-gradient(160deg,#2980B9,#1a5a8a)':'rgba(0,0,0,.06)'};border-radius:10px;padding:6px;text-align:center">
      <div style="font-size:.7rem;color:${isP?'rgba(255,255,255,.8)':'var(--text-mid)'}">👤 ${typeof t!=='undefined'?t('game.you'):'Du'}</div>
      <div style="font-size:1.5rem;font-weight:900;line-height:1;color:${isP?'white':'var(--text-dark)'}">${c.player.score}</div>
      <div style="font-size:.62rem;color:${isP?'rgba(255,255,255,.6)':'var(--text-mid)'};margin-top:2px">${isP?(typeof t!=='undefined'?t('dart.dart_n'):'Pfeil')+' '+(c.dartsThisRound+1)+'/3':'...'}</div>
    </div>
    <div style="text-align:center;font-size:.7rem;color:#999;font-weight:700">VS</div>
    <div style="background:${!isP?'linear-gradient(160deg,#c0392b,#7b0000)':'rgba(0,0,0,.06)'};border-radius:10px;padding:6px;text-align:center">
      <div style="font-size:.7rem;color:${!isP?'rgba(255,255,255,.8)':'var(--text-mid)'}">🤖 CPU</div>
      <div style="font-size:1.5rem;font-weight:900;line-height:1;color:${!isP?'white':'var(--text-dark)'}">${c.cpu.score}</div>
      <div style="font-size:.62rem;color:rgba(255,255,255,.35)">301 DOut</div>
    </div>
    <div id="dart-wind-panel" style="background:rgba(255,255,255,.07);border-radius:8px;padding:4px;text-align:center;font-size:.65rem;color:rgba(255,255,255,.5)">
      <svg id="dart-windsock" width="30" height="18" viewBox="0 0 62 38" style="display:block;margin:0 auto 2px">${this._windsockSVG(c.wind.strength)}</svg>
      <b>${c.wind.name}</b>
    </div>
    <div style="display:flex;flex-direction:column;gap:2px">
      ${c.player.roundDarts.map(d=>`<div style="padding:2px 4px;border-radius:5px;background:${d.pts>0?'#3498DB':'#E74C3C'};color:white;font-size:.68rem;font-weight:700;text-align:center">${d.label}</div>`).join('')}
    </div>
  </div>
  <div style="flex:1;display:flex;justify-content:center">
    <div style="position:relative;width:${BS}px;height:${BS}px;cursor:crosshair" id="dart-wrap">
      <canvas id="dart-canvas" width="${BS}" height="${BS}" style="border-radius:50%;display:block;width:${BS}px;height:${BS}px;box-shadow:0 6px 20px rgba(0,0,0,.3);touch-action:none"></canvas>
      <svg id="dart-overlay" width="${BS}" height="${BS}" style="position:absolute;top:0;left:0;pointer-events:none;border-radius:50%;overflow:hidden">
        <g id="dart-xhair">
          <circle id="xhair-ring" cx="${CX}" cy="${CY}" r="30" fill="none" stroke="rgba(255,255,255,.3)" stroke-width="1.5" stroke-dasharray="5,5"/>
          <line id="xl1" x1="${CX-20}" y1="${CY}" x2="${CX-9}" y2="${CY}" stroke="rgba(255,255,255,.85)" stroke-width="1.8"/>
          <line id="xl2" x1="${CX+9}" y1="${CY}" x2="${CX+20}" y2="${CY}" stroke="rgba(255,255,255,.85)" stroke-width="1.8"/>
          <line id="xl3" x1="${CX}" y1="${CY-20}" x2="${CX}" y2="${CY-9}" stroke="rgba(255,255,255,.85)" stroke-width="1.8"/>
          <line id="xl4" x1="${CX}" y1="${CY+9}" x2="${CX}" y2="${CY+20}" stroke="rgba(255,255,255,.85)" stroke-width="1.8"/>
          <circle id="xdot" cx="${CX}" cy="${CY}" r="5" fill="rgba(255,60,60,.98)"/>
          <line id="xwind" x1="${CX}" y1="${CY}" x2="${CX}" y2="${CY}" stroke="rgba(100,220,255,.9)" stroke-width="4" marker-end="url(#arrowhead)" stroke-dasharray="3,2"/>
        </g>
        <defs><marker id="arrowhead" markerWidth="12" markerHeight="8" refX="6" refY="4" orient="auto"><polygon points="0 0, 12 4, 0 8" fill="rgba(100,200,255,.8)"/></marker></defs>
      </svg>
    </div>
  </div>
  <div id="dart-joy" style="display:flex;flex-direction:column;align-items:center;gap:6px;width:110px;flex-shrink:0;touch-action:none;user-select:none;padding-top:${Math.max(0,Math.round(BS/2-55))}px">
    <div style="font-size:.78rem;color:#FFD700;font-weight:700;text-align:center">🎯 Zielen</div>
    <div id="dart-joy-pad" style="position:relative;width:100px;height:100px;background:rgba(255,215,0,.08);border:3px solid rgba(255,215,0,.5);border-radius:50%;box-shadow:0 0 14px rgba(255,215,0,.2)">
      <div id="dart-joy-knob" style="position:absolute;top:50%;left:50%;width:38px;height:38px;background:linear-gradient(135deg,#FFD700,#F39C12);border:2px solid #fff;border-radius:50%;transform:translate(-50%,-50%);box-shadow:0 2px 8px rgba(0,0,0,.4)"></div>
    </div>
    <div style="font-size:.65rem;color:rgba(255,255,255,.3);text-align:center">⬆️ Bull<br>${typeof t!=='undefined'?t('dart.release_throw'):'los=Wurf'}</div>
    ${!isP?`<div style="color:#E74C3C;font-weight:700;font-size:.78rem;text-align:center">🤖 ${typeof t!=='undefined'?t('game.cpu'):'CPU'}...</div>`:''}
  </div>
</div>
`:`
<div style="display:flex;flex-direction:column;align-items:center;gap:4px">
  <div style="display:flex;align-items:stretch;gap:5px;width:100%;margin-bottom:2px">
    <div style="flex:1;background:${isP?'linear-gradient(135deg,#2980B9,#1a5a8a)':'rgba(0,0,0,.04)'};border-radius:10px;padding:5px 8px;display:flex;align-items:center;justify-content:space-between;gap:4px">
      <div style="font-size:clamp(0.7rem,3vw,0.8rem);color:${isP?'rgba(255,255,255,.85)':'var(--text-mid)'};line-height:1.2">👤 ${typeof t!=='undefined'?t('game.you'):'Du'}<br><span style="font-size:.65rem;opacity:.8">${isP?(typeof t!=='undefined'?t('dart.dart_n'):'Pfeil')+' '+(c.dartsThisRound+1)+'/3':(typeof t!=='undefined'?t('game.wait'):'warte')}</span></div>
      <div style="font-size:clamp(1.6rem,7vw,2rem);font-weight:900;color:${isP?'white':'var(--text-dark)'}">${c.player.score}</div>
    </div>
    <div style="align-self:center;font-weight:700;font-size:.72rem;color:#aaa">VS</div>
    <div style="flex:1;background:${!isP?'linear-gradient(135deg,#c0392b,#7b0000)':'rgba(0,0,0,.04)'};border-radius:10px;padding:5px 8px;display:flex;align-items:center;justify-content:space-between;gap:4px">
      <div style="font-size:clamp(0.7rem,3vw,0.8rem);color:${!isP?'rgba(255,255,255,.85)':'var(--text-mid)'};line-height:1.2">🤖 CPU<br><span style="font-size:.65rem;opacity:.8">301 DOut</span></div>
      <div style="font-size:clamp(1.6rem,7vw,2rem);font-weight:900;color:${!isP?'white':'var(--text-dark)'}">${c.cpu.score}</div>
    </div>
  </div>
  ${c.player.score<=40||c.cpu.score<=40?`<div style="background:rgba(231,76,60,.12);border:1px solid rgba(231,76,60,.3);border-radius:8px;padding:2px 8px;font-size:.7rem;color:#E74C3C;font-weight:700;text-align:center;width:100%;box-sizing:border-box">${typeof t!=='undefined'?t('dart.doubleout_warn'):'⚠️ Double-Out! Letzter Pfeil muss Double oder Bull treffen!'}</div>`:''}
  <div id="dart-wind-panel" style="display:flex;align-items:center;justify-content:center;gap:6px;margin-bottom:2px">
    <svg id="dart-windsock" width="36" height="20" viewBox="0 0 62 38" style="flex-shrink:0">${this._windsockSVG(c.wind.strength)}</svg>
    <span style="font-size:clamp(0.76rem,3.2vw,0.88rem);font-weight:700;color:var(--text-dark)">${c.wind.name}</span>
    <span style="font-size:clamp(0.7rem,3vw,0.82rem);color:var(--text-mid)">${Math.round(c.wind.angle)}°</span>
  </div>
  <div id="dart-wrap" style="position:relative;width:${BS}px;height:${BS}px;cursor:crosshair;flex-shrink:0">
    <canvas id="dart-canvas" width="${BS}" height="${BS}" style="border-radius:50%;display:block;width:${BS}px;height:${BS}px;box-shadow:0 6px 24px rgba(0,0,0,.3);touch-action:none"></canvas>
    <svg id="dart-overlay" width="${BS}" height="${BS}" style="position:absolute;top:0;left:0;pointer-events:none;border-radius:50%;overflow:hidden">
      <g id="dart-xhair">
        <circle id="xhair-ring" cx="${CX}" cy="${CY}" r="30" fill="none" stroke="rgba(255,255,255,.3)" stroke-width="1.5" stroke-dasharray="5,5"/>
        <line id="xl1" x1="${CX-32}" y1="${CY}" x2="${CX-13}" y2="${CY}" stroke="rgba(255,255,255,.88)" stroke-width="2.2"/>
        <line id="xl2" x1="${CX+13}" y1="${CY}" x2="${CX+32}" y2="${CY}" stroke="rgba(255,255,255,.88)" stroke-width="2.2"/>
        <line id="xl3" x1="${CX}" y1="${CY-32}" x2="${CX}" y2="${CY-13}" stroke="rgba(255,255,255,.88)" stroke-width="2.2"/>
        <line id="xl4" x1="${CX}" y1="${CY+13}" x2="${CX}" y2="${CY+32}" stroke="rgba(255,255,255,.88)" stroke-width="2.2"/>
        <circle id="xdot" cx="${CX}" cy="${CY}" r="5" fill="rgba(255,60,60,.98)"/>
        <line id="xwind" x1="${CX}" y1="${CY}" x2="${CX}" y2="${CY}" stroke="rgba(100,220,255,.9)" stroke-width="4" marker-end="url(#arrowhead)" stroke-dasharray="3,2"/>
      </g>
      <defs><marker id="arrowhead" markerWidth="12" markerHeight="8" refX="6" refY="4" orient="auto"><polygon points="0 0, 12 4, 0 8" fill="rgba(100,200,255,.8)"/></marker></defs>
    </svg>
  </div>
  <div style="display:flex;gap:3px;justify-content:center;min-height:18px;flex-wrap:wrap">
    ${c.player.roundDarts.map(d=>`<div style="padding:2px 6px;border-radius:5px;background:${d.pts>0?'#3498DB':'#E74C3C'};color:white;font-size:clamp(0.76rem,3vw,0.86rem);font-weight:700">${d.label}</div>`).join('')}
    ${c.cpu.roundDarts.map(d=>`<div style="padding:2px 6px;border-radius:5px;background:rgba(231,76,60,.18);color:var(--text-dark);font-size:clamp(0.76rem,3vw,0.86rem)">🤖 ${d.label}</div>`).join('')}
  </div>
  <div id="dart-joy" style="display:${isMob2?'flex':'none'};flex-direction:column;align-items:center;gap:6px;padding:4px 0;touch-action:none;user-select:none">
    <div style="font-size:clamp(0.78rem,3.2vw,0.9rem);color:#FFD700;font-weight:700">🎯 Zielen — Loslassen = Wurf</div>
    <div id="dart-joy-pad" style="position:relative;width:${Math.min(160,Math.round(avW*0.42))}px;height:${Math.min(160,Math.round(avW*0.42))}px;background:rgba(255,215,0,.08);border:3px solid rgba(255,215,0,.5);border-radius:50%;box-shadow:0 0 16px rgba(255,215,0,.2)">
      <div id="dart-joy-knob" style="position:absolute;top:50%;left:50%;width:42px;height:42px;background:linear-gradient(135deg,#FFD700,#F39C12);border:2px solid #fff;border-radius:50%;transform:translate(-50%,-50%);box-shadow:0 3px 10px rgba(0,0,0,.4)"></div>
    </div>
    <div style="font-size:clamp(0.7rem,3vw,0.8rem);color:rgba(255,255,255,.3)">⬆️ Mitte = Bullseye</div>
  </div>
  ${!isP?`<div style="text-align:center;color:#E74C3C;font-weight:700;font-size:clamp(0.86rem,3.8vw,1rem);padding:3px 0">🤖 ${typeof t!=='undefined'?t('dart.cpu_throwing'):'CPU wirft...'}</div>`:''}
</div>
`}

</div>`;

    this._drawBoard();
    this._setupPointerEvents();
    this._updateCrosshair();

    if (!isP && !c.gameOver) {
      setTimeout(() => this._cpuRound(), 900);
    }
  },

  _windsockSVG(strength) {
    // strength 0-3.5, lift = 0-1
    const lift = Math.min(1, strength / 3.5);
    const n = 5; // segments
    // Pole (vertical)
    const poleX = 8, poleTop = 4, poleBot = 34;
    let svg = `<line x1="${poleX}" y1="${poleTop}" x2="${poleX}" y2="${poleBot}" stroke="#888" stroke-width="2.5" stroke-linecap="round"/>`;
    // Attachment ring
    svg += `<circle cx="${poleX}" cy="${poleTop+4}" r="2.5" fill="#999"/>`;
    // Sock segments (trapezoids that lift with wind)
    const attachY = poleTop + 4;
    const baseW = 11, tipW = 3;
    const sockLen = 44 + lift * 6;
    const liftY = lift * -10; // tip rises
    const colors = ['#E74C3C','#fff','#E74C3C','#fff','#E74C3C'];
    for (let i = 0; i < n; i++) {
      const t0 = i / n, t1 = (i + 1) / n;
      const x0 = poleX + t0 * sockLen;
      const x1 = poleX + t1 * sockLen;
      const y0 = attachY + t0 * liftY;
      const y1 = attachY + t1 * liftY;
      const w0 = baseW - (baseW - tipW) * t0;
      const w1 = baseW - (baseW - tipW) * t1;
      // Small wave droop on each segment (less when windy)
      const droop = (1 - lift) * 3 * Math.sin(Math.PI * ((t0 + t1) / 2));
      svg += `<polygon points="${x0},${y0-w0/2} ${x1},${y1-w1/2+droop} ${x1},${y1+w1/2+droop} ${x0},${y0+w0/2}"
        fill="${colors[i]}" stroke="rgba(0,0,0,.08)" stroke-width=".5" opacity="${.75+.25*lift}"/>`;
    }
    // Tip ring
    const tipX = poleX + sockLen;
    const tipY = attachY + liftY;
    svg += `<ellipse cx="${tipX}" cy="${tipY}" rx="1.5" ry="${tipW/2}" fill="#aaa"/>`;
    return svg;
  },

  _setupPointerEvents() {
    const wrap = document.getElementById('dart-wrap');
    const canvas = document.getElementById('dart-canvas');
    if (!wrap || !canvas) return;
    const c = this.current;

    const getPos = (clientX, clientY) => {
      const rect = canvas.getBoundingClientRect();
      return {
        cx: (clientX - rect.left) * ((DartGame.current?._BS||270) / rect.width),
        cy: (clientY - rect.top) * ((DartGame.current?._BS||270) / rect.height),
      };
    };

    const onMove = (e) => {
      if (!c || c.gameOver || c.turn !== 'player') return;
      const {cx, cy} = getPos(
        e.clientX ?? e.touches?.[0]?.clientX,
        e.clientY ?? e.touches?.[0]?.clientY
      );
      c.aimCx = cx;
      c.aimCy = cy;
      c.playerAiming = true;
      this._updateCrosshair();
    };

    const onThrow = (e) => {
      if (!c || c.gameOver || c.turn !== 'player') return;
      e.preventDefault();
      // Final aim = mouse pos + breath offset
      const bx = c.breath.ox;
      const by = c.breath.oy;
      const finalCx = c.aimCx + bx;
      const finalCy = c.aimCy + by;
      this._throwAt(finalCx, finalCy);
    };

    wrap.addEventListener('mousemove', onMove);
    wrap.addEventListener('touchmove', e => { e.preventDefault(); onMove(e); }, { passive: false });
    wrap.addEventListener('click', onThrow);
    wrap.addEventListener('touchend', onThrow, { passive: false });
    
    // Mobile joystick for aim (right side of board, only on touch devices)
    const joyEl = document.getElementById('dart-joy');
    const joyPad = document.getElementById('dart-joy-pad');
    const joyTarget = joyPad || joyEl;
    if (joyEl && 'ontouchstart' in window) {
      joyEl.style.display = 'flex';
      let joyOrigin = null, joyActive = false;
      const JR = 60; // joystick physical range in px (bigger = finer control)
      
      joyTarget.addEventListener('touchstart', e => {
        e.preventDefault(); e.stopPropagation();
        joyActive = true;
        const t = e.touches[0];
        joyOrigin = { x: t.clientX, y: t.clientY };
        // Ensure aim is at board center using actual _BS
        const _cx = c._BS ? Math.round(c._BS/2) : 190;
        if (c) { c.aimCx = _cx; c.aimCy = _cx; }
      }, { passive: false });
      
      joyTarget.addEventListener('touchmove', e => {
        e.preventDefault(); e.stopPropagation();
        if (!joyActive || !joyOrigin || !c) return;
        const t = e.touches[0];
        const dx = t.clientX - joyOrigin.x;
        const dy = t.clientY - joyOrigin.y;
        const dist = Math.sqrt(dx*dx+dy*dy);
        const clamped = Math.min(dist, JR);
        const nx = dist > 0 ? dx/dist*clamped : 0;
        const ny = dist > 0 ? dy/dist*clamped : 0;
        // Move the joystick knob visually
        const knob = document.getElementById('dart-joy-knob');
        if (knob) { knob.style.transform = `translate(calc(-50% + ${nx}px), calc(-50% + ${ny}px))`; }
        // Map joystick → board coordinates using actual board size
        // _BS is full board diameter; R (playable radius) ≈ _BS/2 - 5
        const _bs = c._BS || 270;
        const boardR = Math.round(_bs/2 - 5); // actual board radius in px
        const boardCx = Math.round(_bs/2);
        const boardCy = Math.round(_bs/2);
        // Joystick full deflection (JR px) maps to full board radius (boardR px)
        c.aimCx = boardCx + (nx/JR) * boardR * 0.95; // 0.95 = slight margin from edge
        c.aimCy = boardCy + (ny/JR) * boardR * 0.95;
        c.playerAiming = true;
        this._updateCrosshair();
      }, { passive: false });
      
      const joyEnd = e => {
        e.preventDefault(); e.stopPropagation();
        joyActive = false; joyOrigin = null;
        const knobR = document.getElementById('dart-joy-knob');
        if (knobR) knobR.style.transform = 'translate(-50%,-50%)';
        const knob = document.getElementById('dart-joy-knob');
        if (knob) knob.style.transform = 'translate(-50%, -50%)';
        // Throw on release
        if (c && !c.gameOver && c.turn === 'player') {
          const bx = c.breath.ox; const by = c.breath.oy;
          const _defaultC=c._BS?Math.round(c._BS/2):190;
          this._throwAt((c.aimCx||_defaultC)+bx, (c.aimCy||_defaultC)+by);
        }
      };
      joyTarget.addEventListener('touchend', joyEnd, { passive: false });
      joyTarget.addEventListener('touchcancel', joyEnd, { passive: false });
    }
  },

  _updateCrosshair() {
    const c = this.current;
    if (!c) return;
    const xhair = document.getElementById('dart-xhair');
    if (!xhair) return;

    const bx = c.breath.ox;
    const by = c.breath.oy;
    const cx = c.aimCx + bx;
    const cy = c.aimCy + by;

    // Move all crosshair elements
    const offset = 19; // gap from center to line end
    const gap = 11;    // gap around center

    const setLine = (id, x1,y1,x2,y2) => {
      const el = document.getElementById(id);
      if(el){el.setAttribute('x1',x1);el.setAttribute('y1',y1);el.setAttribute('x2',x2);el.setAttribute('y2',y2);}
    };
    setLine('xl1', cx-offset, cy, cx-gap, cy);
    setLine('xl2', cx+gap,    cy, cx+offset, cy);
    setLine('xl3', cx, cy-offset, cx, cy-gap);
    setLine('xl4', cx, cy+gap,    cx, cy+offset);

    const dot = document.getElementById('xdot');
    if(dot){dot.setAttribute('cx',cx);dot.setAttribute('cy',cy);}

    const ring = document.getElementById('xhair-ring');
    if(ring){ring.setAttribute('cx',cx);ring.setAttribute('cy',cy);}

    // Wind arrow on crosshair — shows where wind pushes dart
    const w = c.wind;
    const wr = (w.angle * Math.PI) / 180;
    const windLen = w.strength * 22; // much bigger wind arrow
    const wxEnd = cx + Math.sin(wr) * windLen;
    const wyEnd = cy + Math.cos(wr) * windLen;
    const xwind = document.getElementById('xwind');
    if(xwind){
      xwind.setAttribute('x1', cx); xwind.setAttribute('y1', cy);
      xwind.setAttribute('x2', wxEnd); xwind.setAttribute('y2', wyEnd);
    }
  },

  _refreshWindDisplay() {
    const c = this.current; if (!c) return;
    // Update compass arrow
    const arrow = document.getElementById('dart-arrow');
    if (arrow) arrow.setAttribute('transform', `rotate(${c.wind.angle},26,26)`);
    // Update windsock
    const sock = document.getElementById('dart-windsock');
    if (sock) sock.innerHTML = this._windsockSVG(c.wind.strength);
    // Update info text
    const panel = document.getElementById('dart-wind-panel');
    if (panel) {
      // Replace just the text elements
      const spans = panel.querySelectorAll('div > div');
      if (spans[0]) spans[0].textContent = c.wind.name;
      if (spans[1]) spans[1].textContent = `Richtung: ${Math.round(c.wind.angle)}°`;
      if (spans[3]) spans[3].textContent = `Stärke: ${c.wind.strength.toFixed(1)}/3.5 — ändert sich alle 3-4s`;
      // Update bar
      const bar = panel.querySelector('[style*="border-radius:50px;height:5px"]');
      const fill = bar?.querySelector('[style*="height:100%"]');
      if (fill) {
        fill.style.width = Math.min(100, c.wind.strength / 3.5 * 100) + '%';
        fill.style.background = c.wind.strength<1.2?'#27AE60':c.wind.strength<2.5?'#F39C12':'#E74C3C';
      }
    }
  },

  _throwAt(finalCx, finalCy) {
    const c = this.current;
    // Use actual board size (not hardcoded 135!)
    const _bs2 = this.current?._BS || 270;
    const R = Math.round(_bs2/2 - 5), cx0 = Math.round(_bs2/2), cy0 = Math.round(_bs2/2);
    // Add wind displacement to final position
    const wr = (c.wind.angle * Math.PI) / 180;
    const wp = c.wind.strength * 0.05;
    const fdx = (finalCx - cx0) / R + Math.sin(wr) * wp + (Math.random() - .5) * 0.03;
    const fdy = (finalCy - cy0) / R + Math.cos(wr) * wp + (Math.random() - .5) * 0.03;
    const dist = Math.sqrt(fdx*fdx + fdy*fdy);
    const fpx = cx0 + fdx * R;
    const fpy = cy0 + fdy * R;
    const result = this._calcScore(fdx, fdy, dist);
    this._applyThrow('player', result, fpx, fpy);
  },

  _calcScore(dx, dy, dist) {
    if (dist < 0.045) return { pts:50, label:'🎯 Bull!',  isDouble:false, isBull:true };
    if (dist < 0.115) return { pts:25, label:'Bull 25', isDouble:false, isBull:false };
    if (dist > 1.0)   return { pts:0,  label:'❌ Daneben',isDouble:false, isBull:false };
    // Board: sector 0 (value=20) is centered at top (-PI/2 in canvas = theta=0 clockwise)
    // The draw uses off = -PI/2 - step/2 as START of sector 0
    // so sector 0 spans [-step/2, +step/2] around top
    // Add step/2 offset so sector boundaries match the visual drawing exactly
    const step = (2 * Math.PI) / 20;
    let ang = Math.atan2(dy, dx) + Math.PI/2 + step/2;
    if (ang < 0) ang += 2*Math.PI;
    if (ang >= 2*Math.PI) ang -= 2*Math.PI;
    const si = Math.floor((ang / (2*Math.PI)) * 20) % 20;
    const sv = this.SECTORS[si];
    // Ring boundaries (as fraction of board radius R=130)
    // Bull: <0.045R, Bull25: <0.115R, inner triple: 0.24-0.455, outer single: 0.455-0.86, double: 0.86-0.955
    // Zones match _drawBoard exactly (R_board=130, R_norm=130):
    // Bull inner: dist<0.045, Bull25: dist<0.115
    // Inner single (small): 0.115 to 0.24
    // Inner single (large): 0.24 to 0.45  
    // TRIPLE ring: 0.45 to 0.52
    // Outer single: 0.52 to 0.858
    // DOUBLE ring: 0.858 to 0.955
    if (dist < 0.24)  return { pts:sv,   label:`${sv}`,   isDouble:false, isBull:false };
    if (dist < 0.45)  return { pts:sv,   label:`${sv}`,   isDouble:false, isBull:false };
    if (dist < 0.52)  return { pts:sv*3, label:`T${sv}`,  isDouble:false, isBull:false };
    if (dist < 0.858) return { pts:sv,   label:`${sv}`,   isDouble:false, isBull:false };
    if (dist < 0.955) return { pts:sv*2, label:`D${sv}`,  isDouble:true,  isBull:false };
    return { pts:0, label:'❌ Daneben', isDouble:false, isBull:false };
  },

  _applyThrow(who, result, fpx, fpy) {
    const c = this.current;
    const p = c[who];
    let {pts, label, isDouble, isBull} = result;
    let bust = false;
    const would = p.score - pts;
    if (would < 0)                          { bust=true; pts=0; label='Bust!'; }
    else if (would===0 && !isDouble&&!isBull){ bust=true; pts=0; label='Kein Double!'; }
    else if (would===1)                     { bust=true; pts=0; label='Bust!'; }
    if (!bust) p.score -= pts;
    if (bust||pts===0) c.errors++;
    p.roundDarts.push({ pts, label, owner:who, px:fpx, py:fpy });
    c.dartsThisRound++;

    // Score flash
    const fl = document.createElement('div');
    fl.style.cssText = `position:fixed;top:26%;left:50%;transform:translate(-50%,-50%);font-family:'Fredoka One',cursive;font-size:2rem;color:${pts>0?'#3498DB':'#E74C3C'};text-shadow:0 2px 8px rgba(0,0,0,.4);pointer-events:none;z-index:999;animation:popIn .3s ease`;
    fl.textContent = pts > 0 ? label : `❌ ${label}`;
    document.body.appendChild(fl);
    setTimeout(() => fl.remove(), 900);

    this._drawBoard();

    if (p.score === 0) {
      c.gameOver = true; c.winner = who;
      setTimeout(() => this._showResult(), 700);
      return;
    }

    if (c.dartsThisRound >= 3) {
      // Check for 180! (3 treble-20s = 60+60+60 = 180 pts off score)
      if (who === 'player') {
        const roundPts = c.player.roundDarts.slice(-3).reduce((s,d)=>s+(d.pts||0),0);
        if (roundPts === 180) {
          this._show180();
        }
      }
      c.dartsThisRound = 0;
      // Keep last round's darts visible (stored in prevRoundDarts)
      c.player.prevRoundDarts = [...(c.player.roundDarts||[])];
      c.cpu.prevRoundDarts = [...(c.cpu.roundDarts||[])];
      c.player.roundDarts = [];
      c.cpu.roundDarts = [];
      c.turn = who === 'player' ? 'cpu' : 'player';
      setTimeout(() => this._render(), 600);
    } else {
      setTimeout(() => this._render(), 350);
    }
  },

  _drawBoard() {
    const c = this.current;
    const canvas = document.getElementById('dart-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const _bs = (c && c._BS) ? c._BS : 270;
    const W = _bs, cx0 = Math.round(_bs/2), cy0 = Math.round(_bs/2), R = Math.round(_bs/2 - 5);
    ctx.clearRect(0, 0, W, W);
    const sectors = this.SECTORS, n = 20;
    const step = (2*Math.PI)/n, off = -Math.PI/2 - step/2;

    for (let i = 0; i < n; i++) {
      const a1 = off + i*step, a2 = a1 + step, even = i%2===0;
      // Outer black/cream segments
      ctx.beginPath(); ctx.moveTo(cx0,cy0); ctx.arc(cx0,cy0,R,a1,a2); ctx.closePath();
      ctx.fillStyle = even ? '#1a1a1a' : '#e8dfc8'; ctx.fill();
      // Double ring (green/red)
      ctx.beginPath(); ctx.arc(cx0,cy0,R*.955,a1,a2); ctx.arc(cx0,cy0,R*.858,a2,a1,true); ctx.closePath();
      ctx.fillStyle = even ? '#27AE60' : '#C0392B'; ctx.fill();
      // Inner single
      ctx.beginPath(); ctx.arc(cx0,cy0,R*.858,a1,a2); ctx.arc(cx0,cy0,R*.52,a2,a1,true); ctx.closePath();
      ctx.fillStyle = even ? '#1a1a1a' : '#e8dfc8'; ctx.fill();
      // Triple ring
      ctx.beginPath(); ctx.arc(cx0,cy0,R*.52,a1,a2); ctx.arc(cx0,cy0,R*.45,a2,a1,true); ctx.closePath();
      ctx.fillStyle = even ? '#27AE60' : '#C0392B'; ctx.fill();
      // Inner single small
      ctx.beginPath(); ctx.arc(cx0,cy0,R*.45,a1,a2); ctx.arc(cx0,cy0,R*.24,a2,a1,true); ctx.closePath();
      ctx.fillStyle = even ? '#1a1a1a' : '#e8dfc8'; ctx.fill();
      // Number
      const na = off+(i+.5)*step;
      ctx.save(); ctx.translate(cx0+Math.cos(na)*R*.92, cy0+Math.sin(na)*R*.92);
      ctx.font = `bold ${Math.max(12,Math.round(R*0.13))}px Arial`; ctx.textAlign='center'; ctx.textBaseline='middle';
      ctx.fillStyle = even ? 'white' : '#111'; ctx.fillText(sectors[i],0,0); ctx.restore();
    }
    // Bullseye
    ctx.beginPath(); ctx.arc(cx0,cy0,R*.24,0,Math.PI*2); ctx.fillStyle='#27AE60'; ctx.fill();
    ctx.beginPath(); ctx.arc(cx0,cy0,R*.115,0,Math.PI*2); ctx.fillStyle='#C0392B'; ctx.fill();
    ctx.beginPath(); ctx.arc(cx0,cy0,R*.045,0,Math.PI*2); ctx.fillStyle='#111'; ctx.fill();
    // Border
    ctx.beginPath(); ctx.arc(cx0,cy0,R,0,Math.PI*2);
    ctx.strokeStyle='#8B6914'; ctx.lineWidth=5; ctx.stroke();
    // Draw thrown darts - current round + previous round (faded)
    const prevDarts = [...(c.player.prevRoundDarts||[]), ...(c.cpu.prevRoundDarts||[])];
    const currDarts = [...(c.player.roundDarts||[]), ...(c.cpu.roundDarts||[])];
    
    // Draw previous round darts (faded)
    prevDarts.forEach(d => {
      if (!d.px) return;
      const col = d.owner==='player' ? 'rgba(255,215,0,0.35)' : 'rgba(255,107,107,0.35)';
      ctx.beginPath(); ctx.arc(d.px,d.py,4,0,Math.PI*2);
      ctx.fillStyle=col; ctx.fill();
    });
    
    // Draw current round darts (full color + label)
    currDarts.forEach(d => {
      if (!d.px) return;
      const col = d.owner==='player' ? '#FFD700' : '#ff6b6b';
      // Dart shadow
      ctx.beginPath(); ctx.arc(d.px+1,d.py+1,5,0,Math.PI*2);
      ctx.fillStyle='rgba(0,0,0,0.4)'; ctx.fill();
      // Dart body
      ctx.beginPath(); ctx.arc(d.px,d.py,5,0,Math.PI*2);
      ctx.fillStyle=col; ctx.fill();
      ctx.strokeStyle='#333'; ctx.lineWidth=1.5; ctx.stroke();
      // Dart stick (arrow)
      ctx.beginPath(); ctx.moveTo(d.px,d.py); ctx.lineTo(d.px,d.py-16);
      ctx.strokeStyle=col; ctx.lineWidth=3; ctx.stroke();
      // Arrowhead
      ctx.beginPath();
      ctx.moveTo(d.px-4, d.py-10);
      ctx.lineTo(d.px, d.py-16);
      ctx.lineTo(d.px+4, d.py-10);
      ctx.strokeStyle=col; ctx.lineWidth=2; ctx.stroke();
      // Score label near dart
      ctx.save();
      ctx.font = 'bold 11px Arial';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#fff';
      ctx.strokeStyle = '#000';
      ctx.lineWidth = 3;
      ctx.strokeText(d.label||'', d.px, d.py-22);
      ctx.fillText(d.label||'', d.px, d.py-22);
      ctx.restore();
    });
  },

  _cpuRound() {
    const c = this.current;
    if (c.turn !== 'cpu' || c.gameOver) return;
    const cpu = c.cpu;
    const score = cpu.score;
    const _bs3 = c._BS || 270;
    const R = Math.round(_bs3/2 - 5), cx0 = Math.round(_bs3/2), cy0 = Math.round(_bs3/2);
    const step = (2*Math.PI)/20, off = -Math.PI/2-step/2;
    let aimDx=0, aimDy=0;
    // Target strategy
    if (score === 50 || score === 25) { aimDx=0; aimDy=0; }
    else if (score <= 40 && score%2===0) {
      const dv=score/2, si=this.SECTORS.indexOf(dv);
      if(si>=0){const a=off+(si+.5)*step;aimDx=Math.cos(a)*.91;aimDy=Math.sin(a)*.91;}
    } else { aimDx=Math.cos(off+.5)*0.485; aimDy=Math.sin(off+.5)*0.485; }
    const v=0.1;
    const fdx=aimDx+(Math.random()-.5)*v;
    const fdy=aimDy+(Math.random()-.5)*v;
    const dist=Math.sqrt(fdx*fdx+fdy*fdy);
    const fpx=cx0+fdx*R, fpy=cy0+fdy*R;
    const result=this._calcScore(fdx,fdy,dist);
    setTimeout(() => {
      this._applyThrow('cpu',result,fpx,fpy);
      if(c.dartsThisRound>0&&c.dartsThisRound<3&&c.turn==='cpu'&&!c.gameOver)
        setTimeout(()=>this._cpuRound(),900);
    }, 800);
  },

  _showResult() {
    clearTimeout(this._windTick);
    clearInterval(this._breathTick);
    const c = this.current;
    const won = c.winner==='player';
    const timeMs = Date.now()-c.startTime;
    const rawScore = won ? 100 : 40;
    const finalScore = State.calcFinalScore({rawScore,timeMs,errors:c.errors,passed:won});
    document.getElementById('game-area').innerHTML = `
<div style="text-align:center;padding:20px 0">
  <div style="font-size:3rem">${won?'🎯🏆':'🤖😅'}</div>
  <div style="font-family:'Fredoka One',cursive;font-size:1.8rem;color:var(--mountain-dark);margin:10px 0">
    ${won?(typeof t!=='undefined'?t('dart.you_won'):'Du hast gewonnen!'):(typeof t!=='undefined'?t('dart.cpu_won'):'CPU hat gewonnen!')}
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin:12px 0;max-width:260px;margin-left:auto;margin-right:auto">
    <div style="background:#F0F9FF;border-radius:10px;padding:10px;font-size:.78rem">
      <div style="font-size:1.2rem">🎯</div><b>${typeof t!=='undefined'?t('game.remaining'):'Rest:'} ${c.player.score}</b><br><span style="color:var(--text-mid)">${typeof t!=='undefined'?t('game.you'):'Du'}</span>
    </div>
    <div style="background:#FFF5F5;border-radius:10px;padding:10px;font-size:.78rem">
      <div style="font-size:1.2rem">🤖</div><b>${typeof t!=='undefined'?t('game.remaining'):'Rest:'} ${c.cpu.score}</b><br><span style="color:var(--text-mid)">${typeof t!=='undefined'?t('game.cpu'):'CPU'}</span>
    </div>
    <div style="background:#FFFFF0;border-radius:10px;padding:10px;font-size:.78rem">
      <div style="font-size:1.2rem">⭐</div><b>${finalScore}</b><br><span style="color:var(--text-mid)">Score</span>
    </div>
  </div>
  ${!won?`<button class="btn btn-secondary btn-full" style="margin-bottom:10px;max-width:260px" onclick="DartGame.start(DartGame._lastConfig)">${typeof t!=='undefined'?t('dart.rematch'):'🔄 Revanche!'}</button>`:''}
  <button class="btn btn-primary btn-full" style="max-width:260px" onclick="DartGame._finish(${finalScore},${timeMs},${c.errors})">${typeof t!=='undefined'?t('game.continue'):'Weiter ➜'}</button>
</div>`;
  },

  _finish(s,t,e) {
    clearTimeout(this._windTick);
    clearInterval(this._breathTick);
    if(this.current?.onComplete) this.current.onComplete({rawScore:s,timeMs:t,errors:e,passed:s>=30});
  },
};
window.DartGame = DartGame;
